<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="../model/inserirdados.php" method="POST">
    Nome: <br/>
    <input type="text" name="cxnome"/> <br/>

    Endereço:<br/>
    <input type="text" name="cxendereco"/> <br/>

    Telefone:<br/>
    <input type="text" name="cxtelefone"/> <br/>

    Tipo:<br/>
    <select name="cxtipo">
        <option value="Aluno">Aluno</option>
        <option value="Professor">Professor</option>
    </select>
    <br/>

    E-mail:<br/>
    <input type="text" name="cxemail"/> <br/>

    Idade:<br/>
    <input type="text" name="cxidade"/> <br/>

    CPF:<br/>
    <input type="text" name="cxcpf"/> <br/>
    <input type="submit" value="Enviar">
    
</body>
</html>