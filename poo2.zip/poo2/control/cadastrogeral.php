<?php
    class CadastroGeral{
        public $nome;
        public $endereco;
        public $fone;
        public $tipo;
        public $idade;
        public $email;
        public $cpf;

        function geral ($no,$en,$fn,$tp,$id,$em,$cpf){
            echo "<h1>Dados Gerais</h1>";
            echo "Usuário: " . $this->nome = $no . "</br>";
            echo "Endereço: " . $this->endereco = $en . "</br>";
            echo "Fone: " . $this->fone = $fn . "</br>";
            echo "Tipo: " . $this->tipo = $tp . "</br>";
            echo "Idade: " . $this->idade = $id . "</br>";
            echo "Email: " . $this->email = $em . "</br>";
            echo "CPF: " . $this->cpf = $cpf . "</br>";

        }
    }
?> 